﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        date.Text = DateTime.Now.ToString();
    }
    protected void btnreg_Click(object sender, EventArgs e)
    {
        
            Response.Redirect("Registration.aspx");
        

    }
    protected void btn_Click(object sender, EventArgs e)
    {
        SqlConnection conn = new SqlConnection("Data Source=imran\\sqlexpress;Initial Catalog=LibraryMngSys;Integrated Security=True");
        if (username.Text == " " || psd.Text == " ")
        {
            Response.Write("<script>alert('Please put confirmed values')</script>");
        }
        else
        {
            try
            {
                string s1, s2;
                string ss;
                s1 = username.Text;
                s2 = psd.Text;
                ss = "SELECT * FROM Registration where Username='" + s1 + "' and Userpass='" + s2 + "'";
                conn.Open();
                SqlCommand sc = new SqlCommand(ss, conn);
                SqlDataReader sdr = sc.ExecuteReader();
                if (sdr.Read())
                {
                    Session["Username"] = s1;
                    Session["Userpass"] = s2;
                    Response.Redirect("Notification.aspx");
                }
                else
                {
                    Response.Write("<script>alert('Enter valid username and password----')</script>");
                }
            }
            catch (Exception ee)
            {
                
            }
            finally
            {
                conn.Close();
            }
        }


    }
}