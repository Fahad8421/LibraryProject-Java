﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class PendingFaculty : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["bs"].ConnectionString);
    SqlCommand SqlCmd;
    SqlDataAdapter da;
    DataSet ds = new DataSet();
    String query;
    protected void Page_Load(object sender, EventArgs e)
    {
     /*   if (Session["Username"] != null && Session["Userpass"] != null)
        {

        }
        else
        {
            Response.Redirect("Login.aspx");
        }*/
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            SqlCmd = new SqlCommand(" select * from BookAssignFact where BookID='" + txt_bookid.Text + "' and FactID='" + txt_factid.Text + "'", con);
            da = new SqlDataAdapter(SqlCmd);
            ds = new DataSet();
            da.Fill(ds, "FreshEmp");
            gv1.DataSource = ds.Tables["FreshEmp"];
            gv1.DataBind();
        }
        catch (Exception)
        {

        }
    }
    protected void txt_bookid_TextChanged(object sender, EventArgs e)
    {

    }
    protected void txt_studentid_TextChanged(object sender, EventArgs e)
    {

    }
}