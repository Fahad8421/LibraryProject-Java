﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class Registration : System.Web.UI.Page
{
    SqlConnection conn;
    protected void Page_Load(object sender, EventArgs e)
    {
        date.Text = DateTime.Now.ToString();
        conn = new SqlConnection("Data Source=imran\\sqlexpress;Initial Catalog=LibraryMngSys;Integrated Security=True");
    }
    protected void btn_Click(object sender, EventArgs e)
    {
        string s1 = DateTime.Now.ToString();
        SqlCommand sc=new SqlCommand("INSERT into Registration values('"+username.Text+"','"+psd.Text+"','"+branch.Text+"','"+year.Text+"','"+semester.Text+"','"+s1+"')",conn);
        conn.Open();
        sc.ExecuteNonQuery();
        conn.Close();
        Response.Redirect("Login.aspx");
    }
   
    protected void username_TextChanged(object sender, EventArgs e)
    {

    }
}