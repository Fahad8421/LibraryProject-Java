﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class AddStudent : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["bs"].ConnectionString);
    SqlCommand cmd;
    SqlDataAdapter da;
    DataSet ds;
    string sql_query;
    protected void Page_Load(object sender, EventArgs e)
    {
       /* if (Session["Username"] != null && Session["Userpass"] != null)
        {

        }
        else
        {
            Response.Redirect("Login.aspx");
        }*/

    }
    private void ResetTextbox()
    {
        txtstuid.Text = "";
        txtname.Text = "";
        txtaddress.Text = "";
        txtmobno.Text = "";
        txtyear.Text = "";
        txtsem.Text = "";
    }
    private void ResetEditTextbox()
    {
        txtusid.Text = "";
        txtusid.Style.Add("width", "235px");
        txtusid.Style.Add("background", "#ffffff");
        txtusid.ReadOnly = false;

        btn_check.Visible = true;
        txtuname.Text = "";
        txtuaddress.Text = "";
        txtumobno.Text = "";
        txtuyear.Text = "";
        txtusem.Text = "";
    }
    private void ResetDeleteTextbox()
    {
        txt_delete_bookid.Text = "";
    }

    private void DisableReadOnly_EditTextBoxColor()
    {
        txtuname.ReadOnly = true;
        txtuname.Style.Add("background", "#dddddd");
        txtuaddress.ReadOnly = true;
        txtuaddress.Style.Add("background", "#dddddd");
        txtumobno.ReadOnly = true;
        txtumobno.Style.Add("background", "#dddddd");
        txtuyear.ReadOnly = true;
        txtuyear.Style.Add("background", "#dddddd");
        txtusem.ReadOnly = true;
        txtusem.Style.Add("background", "#dddddd");
    }
    protected void btn_Add_Click(object sender, EventArgs e)
    {
        try
        {
            sql_query = "Insert into Student(srno, name, address,mobno, year,sem) values('" + txtstuid.Text.Trim() + "','" + txtname.Text.Trim() + "','" + txtaddress.Text.Trim() + "','" + txtmobno.Text.Trim() + "','" + txtyear.Text.Trim() + "','" + txtsem.Text.Trim() + "')";
            cmd = new SqlCommand(sql_query, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            lblresult.Text = "Record Inserted Successfully...";
        }
        catch
        {
            con.Close();
        }
    }
    protected void btn_Add_Reset_Click(object sender, EventArgs e)
    {
        ResetTextbox();
    }
    protected void btn_Add_Cancel_Click(object sender, EventArgs e)
    {
        ResetTextbox();
    }
    protected void btn_check_Click(object sender, EventArgs e)
    {
        try
        {
            sql_query = "Select * from Student Where srno='" + txtusid.Text.Trim() + "'";
            da = new SqlDataAdapter(sql_query, con);
            ds = new DataSet();
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtusid.Text = ds.Tables[0].Rows[0]["srno"].ToString();
                txtuname.Text = ds.Tables[0].Rows[0]["name"].ToString();
                txtuaddress.Text = ds.Tables[0].Rows[0]["address"].ToString();
                txtumobno.Text = ds.Tables[0].Rows[0]["mobno"].ToString();
                txtuyear.Text = ds.Tables[0].Rows[0]["year"].ToString();
                txtusem.Text = ds.Tables[0].Rows[0]["sem"].ToString();
                btn_check.Visible = false;

                EnableReadOnly_TextBoxColor();

                div_add.Style.Add("display", "none");
                table_Add.Style.Add("display", "none");
                div_edit.Style.Add("display", "block");
                table_Edit.Style.Add("display", "block");
                div_delete.Style.Add("display", "none");
                table_Delete.Style.Add("display", "none");


                txtusid.Style.Add("width", "300px");
                txtusid.Style.Add("background", "#dddddd");
                txtusid.ReadOnly = true;
            }
        }
        catch
        {
            con.Close();
        }
    }
    private void EnableReadOnly_TextBoxColor()
    {
        txtusid.ReadOnly = false;
        txtusid.Style.Add("background", "#ffffff");
        txtuname.ReadOnly = false;
        txtuname.Style.Add("background", "#ffffff");
        txtuaddress.ReadOnly = false;
        txtuaddress.Style.Add("background", "#ffffff");
        txtumobno.ReadOnly = false;
        txtumobno.Style.Add("background", "#ffffff");
        txtuyear.ReadOnly = false;
        txtuyear.Style.Add("background", "#ffffff");
        txtusem.ReadOnly = false;
        txtusem.Style.Add("background", "#ffffff");
    }
    protected void btn_Delete_Cancel_Click(object sender, EventArgs e)
    {
        ResetDeleteTextbox();
    }
    protected void btn_Update_Click(object sender, EventArgs e)
    {

        try
        {
            sql_query = "Update Student set srno='" + txtusid.Text.Trim() + "', name='" + txtuname.Text.Trim() + "', address='" + txtuaddress.Text.Trim() + "', mobno='" + txtumobno.Text.Trim() + "', year='" + txtuyear.Text.Trim() + "' where srno='" + txtusid.Text.Trim() + "'";
            cmd = new SqlCommand(sql_query, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();
            lblresult.Text = "Record Updated Successfully...";
        }
        catch
        {
            con.Close();
        }
    }
    protected void btn_Update_Reset_Click(object sender, EventArgs e)
    {
        ResetEditTextbox();
        DisableReadOnly_EditTextBoxColor();
    }
    protected void btn_Update_Cancel_Click(object sender, EventArgs e)
    {
        ResetEditTextbox();
        DisableReadOnly_EditTextBoxColor();
    }
    protected void btn_Delete_Click(object sender, EventArgs e)
    {
        try
        {
            sql_query = "Delete Student where srno='" + txt_delete_bookid.Text.Trim() + "'";
            cmd = new SqlCommand(sql_query, con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            div_add.Style.Add("display", "none");
            table_Add.Style.Add("display", "none");
            div_edit.Style.Add("display", "none");
            table_Edit.Style.Add("display", "none");
            div_delete.Style.Add("display", "block");
            table_Delete.Style.Add("display", "block");

            lblresult.Text = "Record Deleted Successfully...";
        }
        catch
        {
            con.Close();
        }
    }
    protected void btn_Delete_Reset_Click(object sender, EventArgs e)
    {
        ResetDeleteTextbox();
    }
}